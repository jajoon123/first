#Session → Set Working Directory → Choose Directory… 디렉토리 변경가능
#View → Panes → Pane Layout 패널들 확인법
#스크립트는 “적는 곳”, 콘솔은 “실행 + 결과 보는 곳” 행은 어디서 하든 결과는 콘솔로 간다.
#“install.packages( ‘패키지명’ ) [ENTER]” 으로 설치
#“library( 패키지명 )” 으로 로드
library(cowsay)
say('hello',by="cow")
#“?키워드” 입력으로 도움말이 브라우저로 자동 연결 
#“??키워드“를 이용하여 온라인 검색도 가능

#이것들 3~4주 참고자료에 있음

#13주차
#install.packages( 'carData')
#library(carData)