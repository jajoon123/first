library(DAAG)
str(tinting)

#$ 변수이름 : 자료형  실제값 예시들
plot(tinting$it,tinting$csoa)

#tinting 데이터셋이 이 패키지 안에 있음
#데이터 구조(structure) 확인 : str
#각 열이 숫자인지 / 범주형인지 확인하는 게 목적


group <- tinting$tint #그룹 변수 저장
plot(tinting$it,tinting$csoa)

plot(tinting$it,tinting$csoa, pch=c(group), col=rainbow(7)) #왜 오류뜨지?


