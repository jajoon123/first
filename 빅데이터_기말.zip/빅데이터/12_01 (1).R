library(carData) #이거 한 파일에만 하면 다 적용되는지 찾아보기
TitanicSurvival
#범주형 데이터
room.class <- TitanicSurvival$passengerClass        
#선실의 변수를 데리고 오기위해서는 타이타닉하고 서바이벌까지 안써도 데이터가 나오는게 보일거다

room.class #다른 이름으로 설정 알아보기 room만 바꾸면되나?

tbl <- table(room.class) #요약된 결과를 볼 수 있어야 한다.
tbl

sum(tbl)
barplot(tbl,main='선실별 탑승객', xlab = '등급', 
        ylab='탑승객 수',col=rainbow(3)) #선그래프 그릴때도 plot bar붙으면 막대그래프

#성별의 따른 선실 남성이 몇명인지 여성이 몇명인지 통계내보고 차트에도 반영
#이런식으로 시험 볼거란 얘기

room1.class <- TitanicSurvival$sex
room1.class
tbl <- table(room1.class) #요약된 결과를 볼 수 있어야 한다.
tbl

sum(tbl)
barplot(tbl,main='선실별 탑승객', xlab = '등급', 
        ylab='탑승객 수',col=rainbow(3)) #선그래프 그릴때도 plot bar붙으면 막대그래프




