#csv건드는거 1개 상관관계 1개

ds1 <- read.csv('d:/fftest.csv')
ds1

ds <- read.csv('d:/fftest.csv', row.names = 'year')
#CSV 파일을 데이터프레임으로 불러옴
#CSV 파일의 year 열을 행 이름(row name) 으로 사용
ds
my.col <- c('red', 'blue', 'pink', 'yellow', 'orange'
            ,'darkgray') #그래프에 사용할 선 색상 벡터
my.lty <- 1:6 #lty : 선 종류(line type)
plot(1:12,ds[1,], main='월별 사망자 추이', type='b'
     ,lty=my.lty[1],ylim=c(300,1200),col=my.col[1])
#1:12 : x축 → 1월~12월
#ds[1,] : 첫 번째 행 → 첫 번째 연도의 월별 사망자 수
#type='b' -> 점 + 선
#lty=my.lty[1] -> 첫번쨰 선 스타일
#ylim=c(300,1200) -> y축 범위 고정
#col=my.col[1] -> 첫번째 색상상

for(i in 2:6){
  lines(1:12,ds[i,],type='b',lty=my.lty[i],col=my.col[i])
}

legend(x='topright', lty=my.lty,col=my.col,legend = 1974:1979)
#그래프 오른쪽 위(topright)에 범례 표시
#선 모양(lty)과 색상(col)을 연도별로 매칭
#legend = 1974:1979
#→ 각 선이 어떤 연도인지 설명
