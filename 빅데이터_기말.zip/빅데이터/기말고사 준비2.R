library(carData)
TitanicSurvival
class(TitanicSurvival)
#"data.frame" 객체의 자료형 확인, TitanicSurvival은 표 형태의 데이터
#classInfo <- TitanicSurvival$passengerClass
#TitanicSurvival 데이터프레임에서 passengerClass 열(컬럼)만 꺼내서
#classInfo라는 변수에 저장
#$ : “데이터프레임에서 특정 열 선택”
classInfo <- TitanicSurvival$passengerClass
classInfo
classTable <- table(classInfo) #table() = 빈도수 집계 함수
classTable
sum(classTable)

barplot(classTable,main="class",xlab="level",ylab="count")
#객실 등급별 승객 수를 막대그래프로 시각화
classTable/sum(classTable)
#classTable,          # 막대 높이 (각 막대의 값)
#main = "class",      # 그래프 제목
#xlab = "level",      # x축 이름
#ylab = "count"       # y축 이름

#각 등급 인원 ÷ 전체 인원 → 비율(확률) 계산

barplot(classTable,main="class",xlab="level",ylab="count",
        col=c('red','green','blue')) #각 막대에 적용할 색상 벡터
pie(classTable,main="class",col=c('red','green','blue')) 
#객실 등급별 승객 비율을 원 그래프로 표현


ageData <- TitanicSurvival$age
ageData
summary(ageData)
#연속형 데이터 요약 통계를 한 번에 보여주는 함수
#Min -최소 나이, 1st QU - 제1사분위수(25% 승객의 나이가 21세 이하),
#Median-가운데 값(절반은 28세 이하, 절반은 28세 이상), 
#Mean-평균, 3rd Qu. (제3사분위수)-75% 승객의 나이가 39세 이하
#Max-최고 나이, NA's -결측값(263명은 나이 정보가 없음 전체중)
hist(ageData) #승객 나이(age)의 분포를 히스토그램으로 그림
#x축: 나이 구간 (예: 0~10, 10~20, 20~30 …)
#y축: 해당 구간에 속한 사람 수
class(ageData) #ageData는 숫자형 벡터


pressure
plot(pressure$temperature,pressure$pressure)
#temperature -> 온도, pressure -> 압력
#온도(x축)와 압력(y축)의 관계를 산점도로 그림,plot
#데이터프레임에서 특정 열(변수)을 선택 $
#산점도 : 두 개의 숫자형 변수 사이의 관계를 점으로 나타낸 그래프

cor(pressure)
is<- subset(iris[,1:4]) #iris R 기본 내장 데이터셋, 
#iris[, 1:4] 행은 전부, 열은 1~4번만 선택
#subset 선택한 데이터에서 조건 필터링을 하기 위한 함수
cor(is)

#Population -> 인구 수, Income -> 1인당 소득, Illiteracy -> 문맹률
#Life.Exp -> 기대 수명, Murder -> 살인 발생률, HS.Grad-> 고등학교 졸업률
#Fros -> 연평균 서리 발생 일수, Area -> 주 면적
tmp <- data.frame(state.x77)
head(tmp) #head()는 데이터의 앞부분(기본 6행) 을 보여주는 함수

is <- iris[,3:4] #iris : R에 기본으로 들어있는 붓꽃(iris) 데이터셋
#Sepal.Length / Sepal.Width / Petal.Length / Petal.Width / Species 중
#Petal.Length, Petal.Width 두 컬럼만 뽑아서
ptr <- as.numeric(iris$Species)

#iris$Species :
#품종 이름 (setosa, versicolor, virginica) 붓꽃 종류 변수
#factor(범주형 변수)

#as.numeric() : -> factor를 숫자로 변환

col <- c("red","green","blue")
plot(is,main="iris",pch=c(ptr),col=col[ptr])
#pch : 점 모양 (plot character)
#ptr는: ptr <- as.numeric(iris$Species) 붓꽃 품종 점 모양

#ptr 값: 1, 2, 3

#col[ptr]:
  
#1 → "red"

#2 → "green"

#3 → "blue"

#👉 Species에 따라 점 색깔 다르게 표시
     