fav <- c('winter', 'fall', 'spring','summer', 'fall','winter', 'summer'
         ,'fall')
fav

ds <- table(fav) #테이블 함수 이용해 요약할거임 fav라는 변수
ds
#원영차트는 결과가 하나 ㅌ\x축y축개념이 없음 pie() 원그래프 작성 함수

pie(ds,main = '선호 계절', radius=1) #main은 차트에 타이틀 다는 것
#원차트 조각 색깔이 다르게 나와야됨

pie(ds,main = '선호 계절', radous=1, col=rainbow(4))#레인보우는 7개 원에 4개만 나오니

pie(ds,main = '선호 계절', radous=1, col=rainbow(2))

#일반 plot은 선 baplat은 막대로 들어가는 거 pie는 원 , 차트는 이 3개만 할거

