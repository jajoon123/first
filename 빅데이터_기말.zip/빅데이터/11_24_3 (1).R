iris

#iris는 R에서 기본으로 제공하는 내장 데이터셋이에요.
#주제: 붓꽃(Iris) 3종의 측정 데이터
#행(row): 150개 (각 개체)
#열(column): 5개
#Sepal.Length – 꽃받침 길이 (cm)
#Sepal.Width – 꽃받침 너비 (cm)
#Petal.Length – 꽃잎 길이 (cm)
#Petal.Width – 꽃잎 너비 (cm)
#Species – 붓꽃 종 (Setosa, Versicolor, Virginica)

ChickWeight
#R에서 제공하는 내장 데이터셋 중 하나예요
#주제: 생후 닭(chick)의 체중 변화 실험
#행(row): 578개 (측정 단위 = 한 마리의 한 시점 측정)
#열(column): 4개
#weight	체중 (g)
#Time	측정 시점 (일)
#Chick	각 닭의 ID
#Diet	사료 종류 (1~4)

library(DAAG)
#DAAG는 “Data Analysis And Graphics” 패키지로 데이터 분석과 시각화 예제용 데이터셋들을 포함하고 있어요.
ds <- table(science$like) #science라는 데이터프레임 안의 like 변수(컬럼)를 선택
ds
#결과분석을 그래프로 줘야한다, 선에대한게 아니라 분포도를 도트모양으로 줄거다
#여기에 몰려있고 여기에 몰려있지 않고 이게 산점도

c1 <- subset(ChickWeight,Chick==1)  #DAAG 에 있는건지
#subset: 조건에 맞는 행(또는 열)만 골라서 새로운 데이터로 만드는 함수
#subset(데이터, 조건)
C21 <- subset(ChickWeight,Chick==21) #어디서 가져오는건지
plot(c1$Time,c1$weight,ylim=c(40,400)) #x축은 시간, y축은 체중 ,선두께 색 등 자유롭게 넣기
#ylim-> y축 범위 40~400으로 고정

mtcars  #mpg 연로, #cyl
#mtcars : R에 기본으로 들어있는 자동차 데이터셋
#mpg : 연비 (mile per gallon)
#wt : 차량 중량 (1000 파운드 단위)
#cyl : 실린더 수
wt <- mtcars$wt #mtcars 데이터에서 중량 열
mpg <- mtcars$mpg #mtcars 데이터에서 연비 열

#중량과 연비에 산점도
plot(wt,mpg,main="중량 연비 그래프", col='red', phc=8 ) 
#phc 오타고 pch인듯

