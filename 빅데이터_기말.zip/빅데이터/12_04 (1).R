#상관관계

head(pressure)
plot(pressure$temperature,pressure$pressure,main='온도와 기압',
     xlab='온도',ylab='기압',col='red')
