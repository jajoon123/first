#15주 동안의 지각비율은 분포도로 알아보기 , 선이 2개여야한다, 기본 선차트
#2개의 데이터 비교하는거해볼거

month=1:15
late=c(2,4,3,2,3,3,4,1,5,2,1,3,2,4,5)
plot(month,late, main='지각생 통계', type='l', lty=1,lwd=1) 
#앞이 x축, 뒤에께 y축

plot(month,late, main='지각생 통계', type='l', lty=1,lwd=1,xlab='15주')
plot(month,late, main='지각생 통계', type='b', lty=1,lwd=1,xlab='15주')
plot(month,late, main='지각생 통계', type='o', lty=1,lwd=1,xlab='15주')
plot(month,late, main='지각생 통계', type='s', lty=1,lwd=1,xlab='15주')

#plots에 오른쪽마우스클릭후 저장 , jpg로 저장 .jpg

plot(month,late, main='지각생 통계', type='s', lty=3,lwd=1,xlab='15주')
plot(month,late, main='지각생 통계', type='s', lty=6,lwd=1,xlab='15주')

plot(month,late, main='지각생 통계', type='s', lty=1,lwd=1,xlab='15주',col='red')

late2=c(3,2,1,4,5,2,5,3,4,1,2,3,1,3,2)
lines(month,late2,type='b',col='blue') #다른선 겹칠때 line함수써야함

#이제 산점도 하나볼거고, r에서 주는 데이터 볼거임
#plots 옆에 패키지 DAAG 설치해야함
#패키지에 INSTALL로 크렌에서 설치 DAAG

#type p -> 점그래프, l -> 선그래프, b -> 점 + 선, o -> 점 위에 선, h-> 막대처럼
#s -> 계단형

#lty -> 선의 종류 : 1 -> 실선, 2->점선, 3-> 점-선 , 4-> 점-점-선
#lwd -> 선의 두께

#lines : 기존 plot() 그래프에 선을 추가하는 함수
