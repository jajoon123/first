﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1st
{
    public partial class Form1 : Form //Form을 상속 //partial은 하나의 클래스를 여러 파일로 나눠서 작성할 수 있게 해주는 키워드
    {
        public Form1()
        {
            InitializeComponent(); //초기화하다 부품 //폼의 디자인 요소를 불러오는 함수
        }

        int x1, y1, x2, y2;

        private void button1_Click(object sender, EventArgs e) //object sender-> 이벤트를 일으킨 객체, EventArgs e -> 이벤트 정보
        {
            this.Refresh(); //-> 현재 폼 다시 그리기, () 넣어줘야함 메서드 this -> 현재 폼
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e) //마우스를 누른 순간 실행되는 함수
        {
            x2 = e.X; 
            y2 = e.Y;
            Graphics g = CreateGraphics(); //클래스 생성방식 //화면에 그림을 그릴 수 있는 도화지 역할을 하는 객체 //new로 생성 불가 protected라서
            Pen pen = new Pen(Color.Blue, 10);//Pen 인스턴스 생성 //(파란색 선, 선 굵기)
            g.DrawLine(pen, x1, y1, x2, y2); //선그리기
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)//마우스를 떼는 순간 실행되는 함수
        { 
            x1 = e.X; //e.X, e.Y는 **마우스를 누른 지점의 좌표(x, y) MouseEventArgs e
            y1 = e.Y; 
        }



    }
}
