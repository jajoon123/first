﻿namespace Picture02
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.설정ToolStripMenuItem = new System.Windows.Forms.MenuStrip();
            this.색상선택ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.선두께ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.초기화ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.설정ToolStripMenuItem.SuspendLayout();
            this.SuspendLayout();
            // 
            // 설정ToolStripMenuItem
            // 
            this.설정ToolStripMenuItem.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.색상선택ToolStripMenuItem,
            this.선두께ToolStripMenuItem,
            this.초기화ToolStripMenuItem});
            this.설정ToolStripMenuItem.Location = new System.Drawing.Point(0, 0);
            this.설정ToolStripMenuItem.Name = "설정ToolStripMenuItem";
            this.설정ToolStripMenuItem.Size = new System.Drawing.Size(800, 24);
            this.설정ToolStripMenuItem.TabIndex = 0;
            this.설정ToolStripMenuItem.Text = "menuStrip1";
            // 
            // 색상선택ToolStripMenuItem
            // 
            this.색상선택ToolStripMenuItem.Name = "색상선택ToolStripMenuItem";
            this.색상선택ToolStripMenuItem.Size = new System.Drawing.Size(67, 20);
            this.색상선택ToolStripMenuItem.Text = "색상선택";
            this.색상선택ToolStripMenuItem.Click += new System.EventHandler(this.색상선택ToolStripMenuItem_Click);
            // 
            // 선두께ToolStripMenuItem
            // 
            this.선두께ToolStripMenuItem.Name = "선두께ToolStripMenuItem";
            this.선두께ToolStripMenuItem.Size = new System.Drawing.Size(79, 20);
            this.선두께ToolStripMenuItem.Text = "선두께입력";
            this.선두께ToolStripMenuItem.Click += new System.EventHandler(this.선두께ToolStripMenuItem_Click);
            // 
            // 초기화ToolStripMenuItem
            // 
            this.초기화ToolStripMenuItem.Name = "초기화ToolStripMenuItem";
            this.초기화ToolStripMenuItem.Size = new System.Drawing.Size(55, 20);
            this.초기화ToolStripMenuItem.Text = "초기화";
            this.초기화ToolStripMenuItem.Click += new System.EventHandler(this.초기화ToolStripMenuItem_Click);
            this.초기화ToolStripMenuItem.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDown);
            this.초기화ToolStripMenuItem.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseUp);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.설정ToolStripMenuItem);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.설정ToolStripMenuItem;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "그림판";
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDown);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseUp);
            this.설정ToolStripMenuItem.ResumeLayout(false);
            this.설정ToolStripMenuItem.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip 설정ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 색상선택ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 선두께ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 초기화ToolStripMenuItem;
        private System.Windows.Forms.ColorDialog colorDialog1;
    }
}

