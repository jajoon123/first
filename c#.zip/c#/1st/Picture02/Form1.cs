﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic; 

namespace Picture02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int x1, y1, x2, y2; 
        int pSize = 1; 
        Pen pen = new Pen(Color.Black, 1);

        private void 색상선택ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();  //ColorDialog는 색상 선택 대화상자 클래스, dlg는 이 대화상자의 인스턴스.
            dlg.ShowDialog(); //실제로 색상 선택 창을 화면에 표시하는 명령
            pen = new Pen(dlg.Color, pSize); //새로운 Pen 객체를 만듭니다. //선의 색상만 변경하고 두께는 그대로 둠.
        }

        private void 선두께ToolStripMenuItem_Click(object sender, EventArgs e) //Microsoft.VisualBasic 참조가 추가되지 않아 발생한 오류로, 참조 추가
                                                                            //→ Microsoft.VisualBasic 체크 → using Microsoft.VisualBasic; 하면 해결됨.
        {
            string str = Microsoft.VisualBasic.Interaction.InputBox("선두께 입력"); //InputBox는 간단한 입력창을 띄우는 함수
            pSize = int.Parse(str);//문자열을 정수로 변환
            pen = new Pen(pen.Color, pSize); //즉, pSize 변수에 새로운 선 두께를 저장
        }

        private void 초기화ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Refresh();
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            x1 = e.X; 
            y1 = e.Y;
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e) 
        {
            x2 = e.X;
            y2 = e.Y;
            Graphics g = CreateGraphics(); 
            g.DrawLine(pen, x1, y1, x2, y2); //펜 객체 사용
        }
    }
}
