﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TextView
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string OrgStr = ""; //결과 : 문자 저장

        private void Form1_Load(object sender, EventArgs e) //폼이 처음 실행될 때(로딩될 때) 자동으로 실행되는 부분
        {
            OrgStr = this.lblResult.Text; //this는 현재 윈폼 화면을 의미 //화면에 있는 lblResult 라벨의 글자를 OrgStr 변수에 저장해둔다.”
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (TextCheck() == true) //TextCheck()라는 사용자 정의 함수를 실행해서, 입력 내용이 유효한지 검사
            { 
                this.lblResult.Text = OrgStr + this.txtEdit.Text; //이 코드는 버튼(btnEdit) 을 클릭했을 때 텍스트박스(txtEdit) 에 입력된 글자를 라벨(lblResult) 에 표시하는 기능이에요.
            }
        }

        private void txtEdit_KeyPress(object sender, KeyPressEventArgs e) //텍스트박스(txtEdit) 안에서 Enter(엔터키) 를 눌렀을  버튼 클릭과 같은 동작(=라벨에 입력값 출력)을 하도록 만든 코드예요.
        {
            if (e.KeyChar == (char)13) //사용자가 Enter 키(ASCII 코드 13) 를 눌렀는지 검사함
            {
                e.Handled = true;//이 키 입력을 처리 완료로 표시해서, 기본 엔터 동작(삑 소리나 줄바꿈 등)을 막음
                if (TextCheck() == true) //입력값이 유효한지 검사하는 함수 실행
                { 
                    this.lblResult.Text = OrgStr + this.txtEdit.Text;
                }
            }
        }

        private bool TextCheck() //bool 타입을 반환하는 사용자 정의 함수.
        {
            if(this.txtEdit.Text != "") return true;//txtEdit(텍스트박스)에 내용이 비어 있지 않으면 (""이 아니면)
            else
            {
                MessageBox.Show("텍스트를 입력하세요!", "알림", MessageBoxButtons.OK, MessageBoxIcon.Error); //텍스트를 입력하세요!”라는 경고창을 띄움.
                this.txtEdit.Focus();//텍스트박스에 커서를 다시 이동시켜서 바로 입력할 수 있게 함
                return false; 
            }
        }

    }
}
