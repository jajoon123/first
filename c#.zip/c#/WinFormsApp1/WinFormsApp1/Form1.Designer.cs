﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblPath = new Label();
            txtPath = new TextBox();
            btnPath = new Button();
            rbtnAll = new RadioButton();
            rbtnHidden = new RadioButton();
            lvFile = new ListView();
            fbdFolder = new FolderBrowserDialog();
            ssbar = new StatusStrip();
            chFilePath = new ColumnHeader();
            chFileName = new ColumnHeader();
            chFileTime = new ColumnHeader();
            chFileSize = new ColumnHeader();
            tsslblResult = new ToolStripStatusLabel();
            ssbar.SuspendLayout();
            SuspendLayout();
            // 
            // lblPath
            // 
            lblPath.AutoSize = true;
            lblPath.Location = new Point(70, 28);
            lblPath.Name = "lblPath";
            lblPath.Size = new Size(38, 15);
            lblPath.TabIndex = 0;
            lblPath.Text = "경로 :";
            // 
            // txtPath
            // 
            txtPath.Location = new Point(143, 20);
            txtPath.Name = "txtPath";
            txtPath.ReadOnly = true;
            txtPath.Size = new Size(371, 23);
            txtPath.TabIndex = 1;
            // 
            // btnPath
            // 
            btnPath.Location = new Point(569, 12);
            btnPath.Name = "btnPath";
            btnPath.Size = new Size(99, 53);
            btnPath.TabIndex = 2;
            btnPath.Text = "경로";
            btnPath.UseVisualStyleBackColor = true;
            btnPath.Click += btnPath_Click;
            // 
            // rbtnAll
            // 
            rbtnAll.AutoSize = true;
            rbtnAll.Checked = true;
            rbtnAll.Location = new Point(47, 378);
            rbtnAll.Name = "rbtnAll";
            rbtnAll.Size = new Size(73, 19);
            rbtnAll.TabIndex = 3;
            rbtnAll.TabStop = true;
            rbtnAll.Text = "전체파일";
            rbtnAll.UseVisualStyleBackColor = true;
            // 
            // rbtnHidden
            // 
            rbtnHidden.AutoSize = true;
            rbtnHidden.Location = new Point(190, 378);
            rbtnHidden.Name = "rbtnHidden";
            rbtnHidden.Size = new Size(73, 19);
            rbtnHidden.TabIndex = 4;
            rbtnHidden.TabStop = true;
            rbtnHidden.Text = "숨김파일";
            rbtnHidden.UseVisualStyleBackColor = true;
            // 
            // lvFile
            // 
            lvFile.Columns.AddRange(new ColumnHeader[] { chFilePath, chFileName, chFileTime, chFileSize });
            lvFile.GridLines = true;
            lvFile.Location = new Point(32, 89);
            lvFile.Name = "lvFile";
            lvFile.Size = new Size(776, 252);
            lvFile.TabIndex = 5;
            lvFile.UseCompatibleStateImageBehavior = false;
            lvFile.View = View.Details;
            // 
            // ssbar
            // 
            ssbar.Items.AddRange(new ToolStripItem[] { tsslblResult });
            ssbar.Location = new Point(0, 428);
            ssbar.Name = "ssbar";
            ssbar.Size = new Size(883, 22);
            ssbar.TabIndex = 6;
            ssbar.Text = "statusStrip1";
            // 
            // chFilePath
            // 
            chFilePath.Text = "경로";
            chFilePath.Width = 400;
            // 
            // chFileName
            // 
            chFileName.Text = "이름";
            chFileName.Width = 120;
            // 
            // chFileTime
            // 
            chFileTime.Text = "수정한 날짜";
            chFileTime.Width = 150;
            // 
            // chFileSize
            // 
            chFileSize.Text = "크기";
            chFileSize.Width = 150;
            // 
            // tsslblResult
            // 
            tsslblResult.Name = "tsslblResult";
            tsslblResult.Size = new Size(122, 17);
            tsslblResult.Text = "폴더 : 0개, 파일 : 0개";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(883, 450);
            Controls.Add(ssbar);
            Controls.Add(lvFile);
            Controls.Add(rbtnHidden);
            Controls.Add(rbtnAll);
            Controls.Add(btnPath);
            Controls.Add(txtPath);
            Controls.Add(lblPath);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Form1";
            Text = "파일 보기";
            ssbar.ResumeLayout(false);
            ssbar.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblPath;
        private TextBox txtPath;
        private Button btnPath;
        private RadioButton rbtnAll;
        private RadioButton rbtnHidden;
        private ListView lvFile;
        private FolderBrowserDialog fbdFolder;
        private StatusStrip ssbar;
        private ColumnHeader chFilePath;
        private ColumnHeader chFileName;
        private ColumnHeader chFileTime;
        private ColumnHeader chFileSize;
        private ToolStripStatusLabel tsslblResult;
    }
}
