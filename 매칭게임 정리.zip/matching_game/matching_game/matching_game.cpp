﻿// matching_game.cpp : 애플리케이션에 대한 진입점을 정의합니다.
//

#include "framework.h"
#include "matching_game.h"
#include "resource.h"
#include <stdlib.h>  // srand(), rand()
#include <time.h>    // time()

#define MAX_LOADSTRING 100

// 전역 변수:
HINSTANCE hInst;                                // 현재 인스턴스입니다.
WCHAR szTitle[MAX_LOADSTRING];                  // 제목 표시줄 텍스트입니다.
WCHAR szWindowClass[MAX_LOADSTRING];            // 기본 창 클래스 이름입니다.

// 이 코드 모듈에 포함된 함수의 선언을 전달합니다:
ATOM                MyRegisterClass(HINSTANCE hInstance);
BOOL                InitInstance(HINSTANCE, int);
LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK    About(HWND, UINT, WPARAM, LPARAM);

int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
                     _In_opt_ HINSTANCE hPrevInstance,
                     _In_ LPWSTR    lpCmdLine,
                     _In_ int       nCmdShow)
{
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);

    // TODO: 여기에 코드를 입력합니다.

    // 전역 문자열을 초기화합니다.
    LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
    LoadStringW(hInstance, IDC_MATCHINGGAME, szWindowClass, MAX_LOADSTRING);
    MyRegisterClass(hInstance);

    // 애플리케이션 초기화를 수행합니다:
    if (!InitInstance (hInstance, nCmdShow))
    {
        return FALSE;
    }

    HACCEL hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_MATCHINGGAME));

    MSG msg;

    // 기본 메시지 루프입니다:
    while (GetMessage(&msg, nullptr, 0, 0))
    {
        if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }

    return (int) msg.wParam;
}



//
//  함수: MyRegisterClass()
//
//  용도: 창 클래스를 등록합니다.
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
    WNDCLASSEXW wcex;

    wcex.cbSize = sizeof(WNDCLASSEX);

    wcex.style          = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc    = WndProc;
    wcex.cbClsExtra     = 0;
    wcex.cbWndExtra     = 0;
    wcex.hInstance      = hInstance;
    wcex.hIcon          = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_MATCHINGGAME));
    wcex.hCursor        = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground  = (HBRUSH)(COLOR_WINDOW+1);
    wcex.lpszMenuName   = MAKEINTRESOURCEW(IDC_MATCHINGGAME);
    wcex.lpszClassName  = szWindowClass;
    wcex.hIconSm        = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

    return RegisterClassExW(&wcex);
}

//
//   함수: InitInstance(HINSTANCE, int)
//
//   용도: 인스턴스 핸들을 저장하고 주 창을 만듭니다.
//
//   주석:
//
//        이 함수를 통해 인스턴스 핸들을 전역 변수에 저장하고
//        주 프로그램 창을 만든 다음 표시합니다.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   hInst = hInstance; // 인스턴스 핸들을 전역 변수에 저장합니다.

   HWND hWnd = CreateWindowW(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, nullptr, nullptr, hInstance, nullptr);

   if (!hWnd)
   {
      return FALSE;
   }

   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);

   return TRUE;
}

//
//  함수: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  용도: 주 창의 메시지를 처리합니다.
//
//  WM_COMMAND  - 애플리케이션 메뉴를 처리합니다.
//  WM_PAINT    - 주 창을 그립니다.
//  WM_DESTROY  - 종료 메시지를 게시하고 반환합니다.
//
//

#define BOARD_SIZE 4 //보드의 크기 (4x4)
#define TILE_SIZE 128  // 각 칸의 크기 (128x128 픽셀)


HBITMAP FruitImages[8]; // 과일 이미지를 저장할 배열

int clickedX[2] = { -1,-1 };
int clickedY[2] = { -1,-1 };  // 클릭된 좌표 저장 (최대 2개)
int clickCount = 0;  // 클릭 횟수 추적

int imageIndices[BOARD_SIZE * BOARD_SIZE];  // 이미지 인덱스를 저장할 배열
bool imagesLoaded = false;  // 이미지를 한 번만 로드하도록 하기 위한 플래그

bool revealed[BOARD_SIZE * BOARD_SIZE] = { false };  // revealed 배열 선언 (각 칸의 이미지가 맞춰졌는지 여부 추적)

// 점수 변수
int score = 0;
#define GAP 10  // 타일 간의 간격 (예: 10픽셀)


int timeLeft = 50;  // 타이머 시간 30초로 설정

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
    case WM_CREATE:
    {
        SetTimer(hWnd, 1, 1000, NULL);  // 1초 간격으로 타이머 설정
    }
    break;
    case WM_TIMER:
    {
        // 게임 클리어가 되었는지 확인
         bool allRevealed = true;
        for (int i = 0; i < BOARD_SIZE * BOARD_SIZE; i++) {
            if (!revealed[i]) {
                allRevealed = false;
                break;
            }
        }

        if (!allRevealed) {
            // 타이머가 0보다 클 때만 타이머를 갱신
            if (timeLeft > 0) {
                timeLeft--;  // 1초씩 줄어들기
                InvalidateRect(hWnd, NULL, TRUE);  // 화면 갱신
            }
            else {
                // 타이머가 0에 도달하면 게임 종료
                KillTimer(hWnd, 1);  // 타이머 종료
                MessageBox(hWnd, L"시간 초과! 게임이 종료되었습니다.", L"게임 종료", MB_OK);
                PostQuitMessage(0);  // 프로그램 종료
            }
        }
        else {
            // 게임이 클리어되었으면 타이머를 멈추기
            KillTimer(hWnd, 1);  // 타이머 종료
        }

        InvalidateRect(hWnd, NULL, TRUE);  // 화면 갱신
    }
    break;
    case WM_PAINT:
    {


        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hWnd, &ps);
        HDC MemDC = CreateCompatibleDC(hdc); // 화면과 호환되는 메모리 DC 생성

       
        if (!imagesLoaded) {
            // 과일 이미지 8개를 로드
            FruitImages[0] = LoadBitmap(hInst, MAKEINTRESOURCE(IDB_BITMAP1));  // 첫 번째 과일 이미지
            FruitImages[1] = LoadBitmap(hInst, MAKEINTRESOURCE(IDB_BITMAP2));   // 두 번째 과일 이미지
            FruitImages[2] = LoadBitmap(hInst, MAKEINTRESOURCE(IDB_BITMAP3));  // 세 번째 과일 이미지
            FruitImages[3] = LoadBitmap(hInst, MAKEINTRESOURCE(IDB_BITMAP4));   // 네 번째 과일 이미지
            FruitImages[4] = LoadBitmap(hInst, MAKEINTRESOURCE(IDB_BITMAP5)); // 다섯 번째 과일 이미지
            FruitImages[5] = LoadBitmap(hInst, MAKEINTRESOURCE(IDB_BITMAP6));   // 여섯 번째 과일 이미지
            FruitImages[6] = LoadBitmap(hInst, MAKEINTRESOURCE(IDB_BITMAP7)); // 일곱 번째 과일 이미지
            FruitImages[7] = LoadBitmap(hInst, MAKEINTRESOURCE(IDB_BITMAP8)); // 여덟 번째 과일 이미지


            // 이미지 인덱스를 초기화
            for (int i = 0; i < BOARD_SIZE * BOARD_SIZE; i++) {
                imageIndices[i] = i % 8;  // 8개의 이미지로 순환
            }

            // 랜덤으로 이미지 인덱스 섞기
            srand((unsigned int)time(NULL));  // 랜덤 시드 설정
            for (int i = 0; i < BOARD_SIZE * BOARD_SIZE; i++) {
                int randomIndex = rand() % (BOARD_SIZE * BOARD_SIZE); // 랜덤 인덱스
                // 이미지 인덱스를 서로 교환
                int temp = imageIndices[i];
                imageIndices[i] = imageIndices[randomIndex];
                imageIndices[randomIndex] = temp;
            }

            imagesLoaded = true;  // 이미지를 로드했으므로 플래그 설정
        }



         // 4x4 판 그리기
        for (int i = 0; i < BOARD_SIZE; i++) {
            for (int j = 0; j < BOARD_SIZE; j++) {
                // 각 칸의 위치 계산
                int x = j * (TILE_SIZE + GAP); // 간격을 포함한 x 위치 계산 //시작 x좌표 0
                int y = i * (TILE_SIZE + GAP); // 간격을 포함한 y 위치 계산 //시작 y좌표 0


                // 각 칸에 이미지를 그리기 전에 경계를 그리기 위해 선 그리기
                // 선택적으로 테두리를 두껍게 그리기 위해 굵은 펜 사용
                HPEN hPen = CreatePen(PS_SOLID, 2, RGB(0, 0, 0)); // 두꺼운 검은색 선
                HPEN hOldPen = (HPEN)SelectObject(hdc, hPen); // 기존 펜을 저장하고 새 펜을 선택

                // 각 칸을 사각형으로 그리기 (구분선 추가)
                MoveToEx(hdc, x, y, NULL);
                LineTo(hdc, x + TILE_SIZE, y);
                LineTo(hdc, x + TILE_SIZE, y + TILE_SIZE);
                LineTo(hdc, x, y + TILE_SIZE);
                LineTo(hdc, x, y);

                // 펜 복원
                SelectObject(hdc, hOldPen);
                DeleteObject(hPen); // 사용한 펜 삭제

                // 이미지가 맞춰졌을 때 검정색으로 그리기
                int index = i * BOARD_SIZE + j;
                if (revealed[index]) {
                    // 검정색으로 해당 칸을 덮어쓰기
                    HBRUSH hBrush = CreateSolidBrush(RGB(0, 0, 0));  // 검정색 브러시
                    HBRUSH hOldBrush = (HBRUSH)SelectObject(hdc, hBrush);
                    // 칸을 덮어쓰는 사각형을 그린다.
                    Rectangle(hdc, x, y, x + TILE_SIZE, y + TILE_SIZE);

                    SelectObject(hdc, hOldBrush);  // 이전 브러시로 복원
                    DeleteObject(hBrush);  // 사용한 브러시 삭제
                }
                else
                {
                    // 클릭된 좌표에 해당하는 칸에 이미지를 보이도록 처리
                    for (int index = 0; index < clickCount; index++) {
                        if (clickedX[index] == j && clickedY[index] == i) {
                            //int imageIndex = (i * BOARD_SIZE + j) % 8; // 이미지는 8개만 있으므로 8개 이미지 순환
                            int imageIndex = imageIndices[i * BOARD_SIZE + j]; // 랜덤으로 배치된 이미지 인덱스
                            HBITMAP currentImage = FruitImages[imageIndex]; // 현재 칸에 맞는 이미지 선택
                            SelectObject(MemDC, currentImage); // 메모리 DC에 이미지 선택

                            // 비트맵을 각 칸에 맞게 복사
                            BitBlt(hdc, x, y, TILE_SIZE, TILE_SIZE, MemDC, 0, 0, SRCCOPY);
                        }
                    }
                }
            }
        }

        // 점수 텍스트 표시
        //wchar_t scoreText[50];
        //swprintf_s(scoreText, 50, L"점수: %d", score);  // 점수를 표시하는 문자열 생성
        //TextOut(hdc, BOARD_SIZE * TILE_SIZE + 20, 10, scoreText, wcslen(scoreText));

        //타이머 표시
        wchar_t timerText[100];
        swprintf_s(timerText, 100, L"남은 시간: %d초",timeLeft);  // 점수와 시간 표시
        TextOut(hdc, BOARD_SIZE * TILE_SIZE + 50, 10, timerText, wcslen(timerText));

        // 점수 및 타이머 텍스트 표시
       /* wchar_t scoreText[100];
        swprintf_s(scoreText, 100, L"점수: %d  남은 시간: %d초", score, timeLeft);  // 점수와 시간 표시
        TextOut(hdc, BOARD_SIZE * TILE_SIZE + 20, 10, scoreText, wcslen(scoreText));*/



        // 자원 해제
        DeleteDC(MemDC); // 메모리 DC 해제

        EndPaint(hWnd, &ps);
    }
    break;
    case WM_LBUTTONDOWN:  // 마우스 왼쪽 버튼 클릭 이벤트
    {
        // 클릭된 좌표 계산 (클릭된 화면 좌표를 받아서 해당 칸의 좌표로 변환)
        int x = LOWORD(lParam);
        int y = HIWORD(lParam);

        // 클릭된 칸의 인덱스를 계산
        int px = x / TILE_SIZE; // 클릭된 칸의 x 좌표 (0부터 시작)
        int py = y / TILE_SIZE; // 클릭된 칸의 y 좌표 (0부터 시작)

        // 이미 클릭된 칸인지 확인
        if ((clickedX[0] == px && clickedY[0] == py) || (clickedX[1] == px && clickedY[1] == py)) {
            // 이미 클릭된 칸이라면 처리하지 않고 리턴
            return 0;
        }

        // 이미 해당 칸이 revealed 상태라면, 즉 이미지가 이미 맞춰졌다면 클릭을 무시
        int index = py * BOARD_SIZE + px;
        if (revealed[index]) {
            return 0;  // 이미 맞춰졌다면 클릭하지 않음
        }


        // 클릭 횟수에 따라 처리
        if (clickCount < 2) {
            clickedX[clickCount] = px;
            clickedY[clickCount] = py;
            clickCount++;

        }
        else {

            // 두 이미지를 비교해서 동일한지 확인
            int firstIndex = clickedY[0] * BOARD_SIZE + clickedX[0];
            int secondIndex = clickedY[1] * BOARD_SIZE + clickedX[1];

            // 이미지가 동일한 경우 점수 추가 및 이미지를 숨기기
            if (imageIndices[firstIndex] == imageIndices[secondIndex]) {

                score += 10;  // 동일한 이미지를 클릭하면 점수 추가

                /*if (score == 80)
                {
                    InvalidateRect(hWnd, NULL, TRUE);  // 화면 갱신 요청
                    UpdateWindow(hWnd);  // 즉시 갱신

                    MessageBox(hWnd, L"게임 클리어", L"게임 종료", MB_OK);
                    PostQuitMessage(0);  // 프로그램 종료
                } */

                revealed[firstIndex] = true;  // 해당 이미지는 더 이상 보이지 않음
                revealed[secondIndex] = true;  // 해당 이미지는 더 이상 보이지 않음


            }
            else {
                // 이미지가 다르면 잠시 대기 후 숨기기
                revealed[firstIndex] = false;
                revealed[secondIndex] = false;

            }

            // 3번째 클릭은 첫 번째 상태로 돌아가도록 초기화
            clickedX[0] = px;
            clickedY[0] = py;
            clickedX[1] = -1;  // 두 번째 이미지는 사라짐
            clickedY[1] = -1;
            clickCount = 1; // 다시 첫 번째 클릭 상태로

        }

        // 모든 이미지가 맞춰졌는지 확인
       bool allRevealed = true;
        for (int i = 0; i < BOARD_SIZE * BOARD_SIZE; i++) {
            if (!revealed[i]) {
                allRevealed = false;
                break;
            }
        }

        // 모든 이미지가 맞춰졌다면 게임 종료
        if (allRevealed) {
            MessageBox(hWnd, L"게임 클리어", L"게임 종료", MB_OK);
            PostQuitMessage(0);  // 프로그램 종료
        }

        // 두 이미지가 맞았을 경우 즉시 화면 갱신
        InvalidateRect(hWnd, NULL, TRUE); // 화면 갱신
    }
    break;

    case WM_COMMAND:
        {
            int wmId = LOWORD(wParam);
            // 메뉴 선택을 구문 분석합니다:
            switch (wmId)
            {
            case IDM_ABOUT:
                DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
                break;
            case IDM_EXIT:
                DestroyWindow(hWnd);
                break;
            default:
                return DefWindowProc(hWnd, message, wParam, lParam);
            }
        }
        break;
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

// 정보 대화 상자의 메시지 처리기입니다.
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    UNREFERENCED_PARAMETER(lParam);
    switch (message)
    {
    case WM_INITDIALOG:
        return (INT_PTR)TRUE;

    case WM_COMMAND:
        if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
        {
            EndDialog(hDlg, LOWORD(wParam));
            return (INT_PTR)TRUE;
        }
        break;
    }
    return (INT_PTR)FALSE;
}
