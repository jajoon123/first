﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++에서 생성한 포함 파일입니다.
// matching_game.rc에서 사용되고 있습니다.
//
#define IDC_MYICON                      2
#define IDD_MATCHINGGAME_DIALOG         102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_MATCHINGGAME                107
#define IDI_SMALL                       108
#define IDC_MATCHINGGAME                109
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     129
#define IDB_BITMAP2                     130
#define IDB_BITMAP3                     131
#define IDB_BITMAP4                     132
#define IDB_BITMAP5                     133
#define IDB_BITMAP6                     134
#define IDB_BITMAP7                     135
#define IDB_BITMAP8                     136
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
